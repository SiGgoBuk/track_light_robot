package com.example.capstone;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText emailInput, passwordInput;
    private Button loginButton;
    private RadioButton loginTab, registerTab;
    private CheckBox rememberCheck;
    private TextView findTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        loginTab = findViewById(R.id.loginTab);
        registerTab = findViewById(R.id.registerTab);
        rememberCheck = findViewById(R.id.rememberCheck);
        findTextView = findViewById(R.id.findTextView);

        SharedPreferences loginPrefs = getSharedPreferences("loginPrefs", MODE_PRIVATE);
        SharedPreferences userPrefs = getSharedPreferences("userPrefs", MODE_PRIVATE);

        // Remember me 설정되어 있다면 이메일만 자동 입력
        if (loginPrefs.getBoolean("remember", false)) {
            emailInput.setText(loginPrefs.getString("email", ""));
            rememberCheck.setChecked(true);
        }

        loginButton.setOnClickListener(v -> {
            String inputEmail = emailInput.getText().toString().trim();
            String inputPassword = passwordInput.getText().toString().trim();

            String savedEmail = userPrefs.getString("email", "");
            String savedPassword = userPrefs.getString("password", "");

            if (inputEmail.equals(savedEmail) && inputPassword.equals(savedPassword)) {
                SharedPreferences.Editor editor = loginPrefs.edit();
                if (rememberCheck.isChecked()) {
                    editor.putString("email", inputEmail);
                    editor.putBoolean("remember", true);
                } else {
                    editor.remove("email");
                    editor.putBoolean("remember", false);
                }
                editor.apply();

                Toast.makeText(this, "로그인 성공", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "로그인 실패. 이메일 또는 비밀번호를 확인하세요.", Toast.LENGTH_SHORT).show();
            }
        });

        registerTab.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        findTextView.setOnClickListener(v -> {
            Toast.makeText(this, "아이디/비밀번호 찾기 기능은 준비 중입니다.", Toast.LENGTH_SHORT).show();
        });
    }
}
