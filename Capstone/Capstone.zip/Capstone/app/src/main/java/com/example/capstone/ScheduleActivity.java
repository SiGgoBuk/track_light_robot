package com.example.capstone;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ScheduleActivity extends AppCompatActivity {

    private TimePicker timePicker;
    private Spinner lightStatusSpinner;
    private Button saveScheduleButton;
    private TextView homeText;

    // 요일 버튼들
    private ToggleButton monButton, tueButton, wedButton, thuButton, friButton, satButton, sunButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        // View 연결
        timePicker = findViewById(R.id.timePicker);
        lightStatusSpinner = findViewById(R.id.lightStatusSpinner);
        saveScheduleButton = findViewById(R.id.saveScheduleButton);
        homeText = findViewById(R.id.homeText);

        monButton = findViewById(R.id.monButton);
        tueButton = findViewById(R.id.tueButton);
        wedButton = findViewById(R.id.wedButton);
        thuButton = findViewById(R.id.thuButton);
        friButton = findViewById(R.id.friButton);
        satButton = findViewById(R.id.satButton);
        sunButton = findViewById(R.id.sunButton);

        // 조명 상태 스피너에 ON/OFF 설정
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.light_status,
                R.layout.spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        lightStatusSpinner.setAdapter(adapter);

        // 일정 등록 버튼 클릭 시
        saveScheduleButton.setOnClickListener(v -> {
            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();
            String status = lightStatusSpinner.getSelectedItem().toString();

            ArrayList<String> selectedDays = new ArrayList<>();
            if (monButton.isChecked()) selectedDays.add("월");
            if (tueButton.isChecked()) selectedDays.add("화");
            if (wedButton.isChecked()) selectedDays.add("수");
            if (thuButton.isChecked()) selectedDays.add("목");
            if (friButton.isChecked()) selectedDays.add("금");
            if (satButton.isChecked()) selectedDays.add("토");
            if (sunButton.isChecked()) selectedDays.add("일");

            if (selectedDays.isEmpty()) {
                Toast.makeText(this, "요일을 하나 이상 선택하세요.", Toast.LENGTH_SHORT).show();
                return;
            }

            String days = String.join(",", selectedDays);
            String time = String.format("%02d:%02d", hour, minute);
            String scheduleString = days + "|" + time + "|" + status;

            SharedPreferences prefs = getSharedPreferences("schedulePrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();

            int count = prefs.getInt("count", 0);
            if (count >= 4) {
                Toast.makeText(this, "최대 4개의 일정만 등록할 수 있습니다.", Toast.LENGTH_SHORT).show();
                return;
            }

            // 중복 확인
            for (int i = 0; i < count; i++) {
                String existing = prefs.getString("schedule_" + i, "");
                if (existing.equals(scheduleString)) {
                    Toast.makeText(this, "이미 등록된 일정입니다.", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            editor.putString("schedule_" + count, scheduleString);
            editor.putInt("count", count + 1);
            editor.apply();

            Toast.makeText(this, "일정이 등록되었습니다.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ScheduleActivity.this, MyPageActivity.class);
            startActivity(intent);
            finish();
        });

        // 홈으로 이동
        homeText.setOnClickListener(v -> {
            Intent intent = new Intent(ScheduleActivity.this, HomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }
}
