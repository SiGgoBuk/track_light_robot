package com.example.capstone;

public class ScheduleItem {
    private String day;
    private String time;
    private String status;
    private boolean isEnabled;

    public ScheduleItem(String day, String time, String status, boolean isEnabled) {
        this.day = day;
        this.time = time;
        this.status = status;
        this.isEnabled = isEnabled;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isEnabled() {
        return isEnabled;
    }

    public void setEnabled(boolean enabled) {
        isEnabled = enabled;
    }
}
