package com.example.capstone;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class HomeActivity extends AppCompatActivity {

    private CardView myPageCard, lightCard, scheduleCard;
    private TextView logoutTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // CardView와 TextView 연결
        myPageCard = findViewById(R.id.mypage);
        lightCard = findViewById(R.id.light);
        scheduleCard = findViewById(R.id.schedule);
        logoutTextView = findViewById(R.id.logoutTextView);

        // 마이페이지 이동
        myPageCard.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, MyPageActivity.class);
            startActivity(intent);
        });

        // 조명 제어 화면 이동
        lightCard.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, LightControlActivity.class);
            startActivity(intent);
        });

        // 일정 등록 화면 이동
        scheduleCard.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, ScheduleActivity.class);
            startActivity(intent);
        });

        // 로그아웃 처리
        logoutTextView.setOnClickListener(v -> {
            SharedPreferences loginPrefs = getSharedPreferences("loginPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = loginPrefs.edit();

            // remember가 체크되어 있으면 이메일과 remember 값은 유지
            if (loginPrefs.getBoolean("remember", false)) {
                String rememberedEmail = loginPrefs.getString("email", "");
                editor.clear(); // 먼저 전체 초기화
                editor.putString("email", rememberedEmail);
                editor.putBoolean("remember", true);
            } else {
                editor.clear(); // remember 체크 안 되어 있으면 전부 삭제
            }

            editor.apply();

            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}
