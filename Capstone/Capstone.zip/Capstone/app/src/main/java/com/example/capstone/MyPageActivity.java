package com.example.capstone;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyPageActivity extends AppCompatActivity {

    private RecyclerView scheduleRecyclerView;
    private ScheduleAdapter adapter;
    private ArrayList<ScheduleItem> scheduleList;
    private TextView userNameText, userEmailText, homeText, logoutText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mypage);

        userNameText = findViewById(R.id.userNameText);
        userEmailText = findViewById(R.id.userEmailText);
        homeText = findViewById(R.id.homeText);
        logoutText = findViewById(R.id.logoutText);

        // 사용자 정보 표시
        SharedPreferences userPrefs = getSharedPreferences("userPrefs", MODE_PRIVATE);
        userNameText.setText("이름: " + userPrefs.getString("name", ""));
        userEmailText.setText("이메일: " + userPrefs.getString("email", ""));

        // 일정 불러오기
        scheduleRecyclerView = findViewById(R.id.scheduleRecyclerView);
        scheduleRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        scheduleList = loadSchedules();
        adapter = new ScheduleAdapter(scheduleList, new ScheduleAdapter.OnItemActionListener() {
            @Override
            public void onDelete(int position) {
                scheduleList.remove(position);
                adapter.notifyItemRemoved(position);
                saveSchedules();
            }

            @Override
            public void onToggle(int position, boolean isOn) {
                scheduleList.get(position).setEnabled(isOn);
                // 필요 시 상태 저장 로직 추가 가능
            }
        });
        scheduleRecyclerView.setAdapter(adapter);

        // 홈으로 이동
        homeText.setOnClickListener(v -> {
            Intent intent = new Intent(MyPageActivity.this, HomeActivity.class);
            startActivity(intent);
        });

        // 로그아웃 처리
        logoutText.setOnClickListener(v -> {
            SharedPreferences loginPrefs = getSharedPreferences("loginPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = loginPrefs.edit();

            // remember가 체크되어 있으면 이메일과 remember 값은 유지
            if (loginPrefs.getBoolean("remember", false)) {
                String rememberedEmail = loginPrefs.getString("email", "");
                editor.clear(); // 먼저 전체 초기화
                editor.putString("email", rememberedEmail);
                editor.putBoolean("remember", true);
            } else {
                editor.clear(); // remember 체크 안 되어 있으면 전부 삭제
            }

            editor.apply();

            Intent intent = new Intent(MyPageActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private ArrayList<ScheduleItem> loadSchedules() {
        ArrayList<ScheduleItem> list = new ArrayList<>();
        SharedPreferences prefs = getSharedPreferences("schedulePrefs", MODE_PRIVATE);
        int count = prefs.getInt("count", 0);

        for (int i = 0; i < count && i < 4; i++) {
            String schedule = prefs.getString("schedule_" + i, "");
            if (!schedule.isEmpty()) {
                String[] parts = schedule.split("\\|");  // ← 중요: | 는 정규식에서 특수문자이므로 \\| 로 처리
                if (parts.length == 3) {
                    String day = parts[0];    // 예: "Mon,Tue"
                    String time = parts[1];   // 예: "08:30"
                    String status = parts[2]; // 예: "ON"

                    list.add(new ScheduleItem(day, time, status, true));
                }
            }
        }

        return list;
    }

    private void saveSchedules() {
        SharedPreferences prefs = getSharedPreferences("schedulePrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.clear();

        int count = Math.min(scheduleList.size(), 4);
        editor.putInt("count", count);

        for (int i = 0; i < count; i++) {
            ScheduleItem item = scheduleList.get(i);
            String value = item.getDay() + " " + item.getTime() + " " + item.getStatus();
            editor.putString("schedule_" + i, value);
        }

        editor.apply();
    }
}
