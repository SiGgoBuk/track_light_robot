package com.example.capstone;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ColorPickerActivity extends AppCompatActivity {

    private SeekBar seekBarRed, seekBarGreen, seekBarBlue;
    private View colorPreview;
    private ImageView imageView;
    private int red = 255, green = 255, blue = 255;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_picker);

        seekBarRed = findViewById(R.id.seekBarRed);
        seekBarGreen = findViewById(R.id.seekBarGreen);
        seekBarBlue = findViewById(R.id.seekBarBlue);
        colorPreview = findViewById(R.id.colorPreview);
        imageView = findViewById(R.id.imageView6); // 전구 이미지
        TextView homeText = findViewById(R.id.homeText);

        // SeekBar 리스너 설정
        SeekBar.OnSeekBarChangeListener colorChangeListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                red = seekBarRed.getProgress();
                green = seekBarGreen.getProgress();
                blue = seekBarBlue.getProgress();
                updateColorPreview();
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        };

        seekBarRed.setOnSeekBarChangeListener(colorChangeListener);
        seekBarGreen.setOnSeekBarChangeListener(colorChangeListener);
        seekBarBlue.setOnSeekBarChangeListener(colorChangeListener);

        // 색상 적용 버튼 클릭
        Button applyColorButton = findViewById(R.id.applyColorButton);
        applyColorButton.setOnClickListener(view -> {
            int color = Color.rgb(red, green, blue);
            imageView.setColorFilter(color); // 전구 이미지에 색상 적용
        });

        // 초기 색상 반영
        updateColorPreview();

        homeText.setOnClickListener(view -> {
            Intent intent = new Intent(ColorPickerActivity.this, LightControlActivity.class);
            startActivity(intent);
            finish(); // 현재 액티비티 종료
        });
    }

    private void updateColorPreview() {
        int color = Color.rgb(red, green, blue);
        colorPreview.setBackgroundColor(color);
    }
}

