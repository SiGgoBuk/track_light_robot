package com.example.capstone;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.capstone.api.AnalysisApi;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AnalysisActivity extends AppCompatActivity {

    private TextView avgBrightnessText;
    private TextView avgSensorText;
    private TextView mostUsedLightModeText;

    private TextView avgMotorSpeedText;
    private TextView mostUsedMotorModeText;
    private TextView avgDistanceText;

    private static final long PRODUCT_ID = 2; // 실제 productId로 교체 필요

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analysis);

        // 텍스트뷰 바인딩
        avgBrightnessText = findViewById(R.id.avgBrightness);
        avgSensorText = findViewById(R.id.avgSensor);
        mostUsedLightModeText = findViewById(R.id.mostUsedLightMode);

        avgMotorSpeedText = findViewById(R.id.avgMotorSpeed);
        mostUsedMotorModeText = findViewById(R.id.mostUsedMotorMode);
        avgDistanceText = findViewById(R.id.avgDistance);

        TextView backText = findViewById(R.id.backText);
        backText.setOnClickListener(v -> finish());

        // 분석 정보 가져오기
        fetchAnalysisData();
    }

    private void fetchAnalysisData() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://lightproject.duckdns.org/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        AnalysisApi api = retrofit.create(AnalysisApi.class);
        api.getSummary(PRODUCT_ID).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Object> data = response.body();

                    int avgBrightness = ((Double) data.get("avgBrightness")).intValue();
                    int avgSensor = ((Double) data.get("avgSensor")).intValue();
                    String mostUsedMode = (String) data.get("mostUsedMode");

                    int left = ((Double) data.get("avgLeftSpeed")).intValue();
                    int right = ((Double) data.get("avgRightSpeed")).intValue();
                    String mostUsedMotor = (String) data.get("mostUsedMotorMode");
                    int ultrasonic = ((Double) data.get("avgUltrasonic")).intValue();

                    // 텍스트뷰 업데이트
                    avgBrightnessText.setText("💡 평균 밝기: " + avgBrightness + " / 765");
                    avgSensorText.setText("🌥 평균 조도 센서 값: " + avgSensor);
                    mostUsedLightModeText.setText("🧭 가장 많이 사용된 모드: " + mostUsedMode);

                    avgMotorSpeedText.setText("⚙ 평균 좌/우 속도: " + left + " / " + right);
                    mostUsedMotorModeText.setText("📘 가장 많이 사용된 모드: " + mostUsedMotor);
                    avgDistanceText.setText("🦭 평균 초음파 거리: " + ultrasonic + " cm");

                } else {
                    Toast.makeText(AnalysisActivity.this, "분석 정보 로드 실패", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                Toast.makeText(AnalysisActivity.this, "네트워크 오류: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
